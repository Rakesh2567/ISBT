import Hero from "@/components/Hero";
import ExamGrid from "@/components/ExamGrid";
import TopScores from "@/components/TopScores";

export default function Home() {
  return (
    <>
      <Hero />
      <ExamGrid />
      <TopScores />
    </>
  );
}
