export type ExamSlug = "banking" | "ssc" | "railway" | "opsc" | "ossc" | "osssc" | "aso";

export interface Exam { slug: ExamSlug; name: string; sub: string }

/** Row shape of the isbt_kv table used by the cloud sync (see ISBT CLOUD SYNC script). */
export interface KvRow { key: string; value: unknown; rev: number }

export interface Attempt {
  uid?: string; name?: string; ts: number;
  test?: string; title?: string; score?: number; pct?: number;
}
