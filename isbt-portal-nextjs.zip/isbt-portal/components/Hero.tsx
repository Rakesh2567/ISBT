import Link from "next/link";

const perks = ["Latest Pattern", "Real Exam Interface", "Detailed Solutions", "Performance Analysis"];

export default function Hero() {
  return (
    <section id="home" className="bg-gradient-to-b from-white to-surface px-6 py-20 text-center">
      <span className="inline-block rounded-full border border-blue-200 bg-blue-50 px-4 py-1.5 text-[11px] font-extrabold uppercase tracking-widest text-brand-blue">
        India&apos;s trusted online test platform
      </span>
      <h1 className="mx-auto mt-6 max-w-3xl text-5xl font-black leading-tight text-navy md:text-6xl">
        PRACTICE SMARTER. <span className="text-brand-red">PERFORM BETTER.</span>
      </h1>
      <p className="mx-auto mt-6 max-w-2xl text-base font-semibold text-black">
        ISBT&apos;s preparation ecosystem covers Banking, SSC, Railway and Odisha competitive exams, with subject
        practice in Mathematics, Reasoning, English and General Knowledge / General Awareness.
      </p>
      <div className="mt-8 flex justify-center gap-3">
        <Link href="/mock-tests" className="rounded-xl bg-brand-red px-6 py-3.5 text-sm font-extrabold text-white shadow-lg">
          Explore Mock Tests →
        </Link>
        <Link href="/mock-tests?free=1" className="rounded-xl border border-line bg-white px-6 py-3.5 text-sm font-extrabold text-navy">
          Free Test
        </Link>
      </div>
      <ul className="mx-auto mt-10 flex max-w-3xl flex-wrap justify-center gap-x-10 gap-y-3 text-xs font-bold text-muted">
        {perks.map((p) => <li key={p}>✓ {p}</li>)}
      </ul>
    </section>
  );
}
