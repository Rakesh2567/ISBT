import Image from "next/image";
import Link from "next/link";
import { EXAMS } from "@/lib/exams";

const links = [
  { href: "/", label: "Home" },
  { href: "/mock-tests", label: "Mock Tests" },
  { href: "/library", label: "Library", tag: "NEW" },
  { href: "/study", label: "Study Materials", tag: "NEW" },
  { href: "/current-affairs", label: "Current Affairs" },
  { href: "/#leaderboard", label: "Results" },
];

export default function Header() {
  return (
    <header className="sticky top-0 z-40 border-b border-line bg-white/95 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center gap-6 px-6 py-3">
        <Link href="/" aria-label="ISBT home">
          <Image src="/logo.png" alt="ISBT" width={170} height={72} priority className="h-auto max-h-[72px] w-auto" />
        </Link>

        <nav className="hidden flex-1 items-center gap-7 text-sm font-bold text-navy lg:flex">
          <Link href="/">Home</Link>
          <div className="group relative">
            <Link href="/exams">Exams ⌄</Link>
            <div className="invisible absolute left-0 top-full w-64 rounded-xl border border-line bg-white p-2 opacity-0 shadow-card transition group-hover:visible group-hover:opacity-100">
              {EXAMS.map((e) => (
                <Link key={e.slug} href={`/exams/${e.slug}`} className="block rounded-lg px-3 py-2 hover:bg-surface">
                  <b className="block">{e.name}</b>
                  <small className="font-medium text-muted">{e.sub}</small>
                </Link>
              ))}
            </div>
          </div>
          {links.slice(1).map((l) => (
            <Link key={l.href} href={l.href} className="flex items-center gap-1.5">
              {l.label}
              {l.tag && <span className="rounded-full bg-brand-red px-1.5 py-0.5 text-[9px] font-extrabold text-white">{l.tag}</span>}
            </Link>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-3">
          <input
            type="search"
            placeholder="Search exams, tests..."
            className="hidden w-48 rounded-xl border border-line px-3 py-2 text-xs md:block"
          />
          <Link href="/login" className="text-sm font-bold text-navy">Login</Link>
          <Link href="/register" className="rounded-xl bg-brand-red px-5 py-2.5 text-sm font-extrabold text-white">Register</Link>
        </div>
      </div>
    </header>
  );
}
