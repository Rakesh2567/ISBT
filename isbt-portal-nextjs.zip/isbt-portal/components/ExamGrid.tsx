import Link from "next/link";
import { EXAMS } from "@/lib/exams";

export default function ExamGrid() {
  return (
    <section id="exams" className="mx-auto max-w-7xl px-6 py-16">
      <div className="mb-8 flex items-end justify-between">
        <div>
          <h2 className="font-serif text-3xl font-black text-navy">Choose Your Exam</h2>
          <p className="text-sm text-muted">Open an exam, then choose the exact subject — not English only.</p>
        </div>
        <Link href="/exams" className="text-xs font-extrabold text-brand-blue">View All Exams →</Link>
      </div>
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4 xl:grid-cols-7">
        {EXAMS.map((e) => (
          <Link key={e.slug} href={`/exams/${e.slug}`} className="rounded-2xl border border-line p-4 transition hover:shadow-card">
            <div className="mb-4 h-24 rounded-xl bg-surface" />
            <b className="block text-navy">{e.name}</b>
            <small className="text-muted">{e.sub}</small>
          </Link>
        ))}
      </div>
    </section>
  );
}
