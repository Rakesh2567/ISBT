"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import type { Attempt } from "@/types";

type Row = { name: string; pct: number; test: string };

/** Best attempt per student, ranked by % — port of the "Top Scores" script. */
export default function TopScores() {
  const [rows, setRows] = useState<Row[] | null>(null);

  useEffect(() => {
    let alive = true;
    supabase.from("isbt_kv").select("value").eq("key", "attempts").maybeSingle().then(({ data }) => {
      const list = (Array.isArray(data?.value) ? data.value : []) as Attempt[];
      const best = new Map<string, Row>();
      for (const a of list) {
        const id = String(a.uid ?? a.name ?? "x");
        const pct = Number(a.pct ?? a.score ?? 0);
        if (!best.has(id) || best.get(id)!.pct < pct)
          best.set(id, { name: String(a.name ?? "Student"), pct, test: String(a.test ?? a.title ?? "") });
      }
      if (alive) setRows([...best.values()].sort((x, y) => y.pct - x.pct).slice(0, 10));
    });
    return () => { alive = false; };
  }, []);

  return (
    <section id="leaderboard" className="mx-auto max-w-7xl px-6 py-12">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black text-navy">Top Scores</h2>
          <p className="text-sm text-muted">Live rankings from submitted mock tests.</p>
        </div>
        <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-extrabold text-ok">● LIVE</span>
      </div>
      {rows === null && <p className="text-muted">Loading results…</p>}
      {rows?.length === 0 && <p className="text-muted">No results yet.</p>}
      <ol className="space-y-2">
        {rows?.map((r, i) => (
          <li key={r.name + i} className="flex items-center gap-4 rounded-xl border border-line px-4 py-3">
            <span className="w-6 font-black text-brand-red">{i + 1}</span>
            <span className="flex-1 font-bold text-navy">{r.name}</span>
            <span className="text-xs text-muted">{r.test}</span>
            <b>{r.pct.toFixed(1)}%</b>
          </li>
        ))}
      </ol>
    </section>
  );
}
