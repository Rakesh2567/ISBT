import type { Exam } from "@/types";

// Taken from the Exams dropdown in the original navbar.
export const EXAMS: Exam[] = [
  { slug: "banking", name: "Banking", sub: "SBI, IBPS, RRB, NABARD" },
  { slug: "ssc", name: "SSC", sub: "CGL, CHSL, MTS, CPO" },
  { slug: "railway", name: "Railway", sub: "RRB NTPC, Group D, ALP, JE" },
  { slug: "opsc", name: "OPSC", sub: "OCS, ASO, AEE" },
  { slug: "ossc", name: "OSSC", sub: "CGL, RI, Amin, SI" },
  { slug: "osssc", name: "OSSSC", sub: "PEO, JA, RI, ICDS" },
  { slug: "aso", name: "ASO", sub: "Odisha ASO & related" },
];
