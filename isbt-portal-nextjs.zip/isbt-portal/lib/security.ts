import DOMPurify from "isomorphic-dompurify";

/** http(s) links only (port of window.safeUrl). Returns "" when unsafe. */
export function safeUrl(u: unknown): string {
  const s = String(u ?? "").trim();
  return s === "-" || /^https?:\/\/[^\s'"<>\\`]+$/i.test(s) ? s : "";
}

/** https or inline raster data-URI images only (port of window.safeImg). */
export function safeImg(u: unknown): string {
  const s = String(u ?? "").trim();
  return s === "-" ||
    /^(https:\/\/[^\s'"()<>\\`]+|data:image\/(png|jpe?g|gif|webp|avif);base64,[A-Za-z0-9+/=]+)$/i.test(s)
    ? s : "";
}

/** Sanitise admin/user HTML before dangerouslySetInnerHTML (replaces window.cleanHTML). */
export function cleanHTML(html: unknown): string {
  return DOMPurify.sanitize(String(html ?? ""), {
    FORBID_TAGS: ["style", "form", "base", "link", "meta", "iframe", "object", "embed", "svg", "math"],
    FORBID_ATTR: ["srcdoc", "formaction", "action"],
    ALLOWED_URI_REGEXP: /^(?:https?:|mailto:|tel:|#)/i,
  });
}
