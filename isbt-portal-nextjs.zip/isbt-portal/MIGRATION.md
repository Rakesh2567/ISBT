# ISBT portal: HTML → Next.js + TypeScript + Tailwind

## Done in this scaffold
| Original | Now |
|---|---|
| Script 1 security config, `safeUrl/safeImg/cleanHTML` | `lib/security.ts` (cleanHTML now uses DOMPurify) |
| CSP meta tag, HTTPS redirect | `next.config.ts` real headers (+HSTS, frame-ancestors) |
| `:root` colour tokens | `@theme` in `app/globals.css` |
| Navbar, hero, exam cards | `components/Header|Hero|ExamGrid` |
| Script 19 Top Scores | `components/TopScores.tsx` |
| Script 2 Supabase sync (hard-coded key) | `lib/supabase.ts` + `.env` |

## Not yet ported (original script → target)
| # | Original script | Target |
|---|---|---|
| 3 | embedded images (`IMG`) | `public/` files |
| 4, 6 | NOTES, Library + Study Desk | `app/library`, `app/study` |
| 7 | Current Affairs | `app/current-affairs` |
| 5, 14, 15 | exam open-in-new-tab, papers, subject-wise runner, results | `app/exams/[slug]`, `app/test/[id]` |
| 8, 9, 10, 16 | site store, admin banners/home control | server data from Supabase |
| 12 | pdf.js reader | `components/PdfReader.tsx` (`pdfjs-dist`) |
| 13, 20 | banner slider | `components/BannerSlider.tsx` |
| 17 | back-button handling | free with App Router |

## Before going live
Turn on RLS for every table, make `isbt-files` private, and move login behind Supabase Auth.
